title: Not in China, how do I see China's iQiyi, Youku, Tencent video?
date: '2019-08-08 14:46:26'
updated: '2019-08-09 23:07:50'
tags: [More]
permalink: /articles/2019/08/08/1565246785984.html
---
There is a plugin "Malus" that is very easy to use to get back to the country to speed up the server, HD and not stuck. You can watch iQiyi, Youku, Tencent, etc., and also support qq music, Netease cloud, shrimp music and so on. Android, windows, chrome, mac versions are available.

The following is the official website address:
[https://getmalus.com/](https://link.zhihu.com/?target=https%3A//getmalus.com/)
