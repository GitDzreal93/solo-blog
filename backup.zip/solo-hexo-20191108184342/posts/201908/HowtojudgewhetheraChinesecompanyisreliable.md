title: How to judge whether a Chinese company is reliable?
date: '2019-08-08 20:14:32'
updated: '2019-08-09 23:07:07'
tags: [More]
permalink: /articles/2019/08/08/1565266472818.html
---
From multinational cooperation between enterprises to small individual job seekers and wealth management investments, it is necessary to find out the details of each other in advance so that they can know each other and avoid falling into a risk trap.

**The following information can be obtained from [National Enterprise Credit Information Publicity System](http://www.gsxt.gov.cn/)


**How to use this website, please see my other article "How to use the China Enterprise Credit Information Publicity System website?"**

**1) Check the registered capital**
The registered capital of a company is very important information, it represents the company's shareholders willing to take on the company's responsibility. The higher the registered capital, the greater the debt ceiling that must be borne after the risk occurs. Therefore, registered capital can also be considered as a sign of corporate credit.

**2) See registration time**
Generally speaking, the earlier a company is registered, the more experience it has. The more likely it is to have a mature business model, profit model, and market channels, the stronger the company's strength and ability to withstand risks.

**3) See the registration place**
If the actual address of the target company is inconsistent with its externally claimed address, or if it is inconsistent with the address on its business license, the company may be at risk.

**4) Look at the corporate map**
When a company's parent company or subsidiary has been deeply involved in debt disputes, information on untrustworthy executors and even bankruptcy, the company's operational risks will also increase accordingly.

**5) Look at the legal business scope of the company**
When you find that a company is doing business outside its legal business, it has the illegal business risk of “selling the dog”.

**6) See the changing experience of the company**
- When companies frequently change their registered addresses, representing the location of the company is not stable, you need to pay great attention.
- When the capital reduction situation occurs frequently in the registration information of the enterprise, there is a great possibility that the shareholder or the parent company may escape the capital to escape.

- Frequent changes in shareholders, or the change of legal person shareholders into natural person shareholders, is likely to be a problem in business operations, and shareholders are evading responsibility.

- When a company's business scope changes, some of its business is removed, and the company is still actually engaged in the business, it needs to carefully consider the risk of illegal business.

**7) Check disputes**
If the company has been included in the untrustworthy enforced person, it means that the company is very likely to have the inability to repay or inadvertently repay the arrears, and has very clear credit risk.
