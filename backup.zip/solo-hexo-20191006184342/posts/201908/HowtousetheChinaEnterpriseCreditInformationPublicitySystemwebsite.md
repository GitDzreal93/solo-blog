title: How to use the China Enterprise Credit Information Publicity System website?
date: '2019-08-08 20:16:08'
updated: '2019-08-18 13:07:54'
tags: [待分类]
permalink: /articles/2019/08/08/1565266568753.html
---
![](https://img.hacpai.com/bing/20181011.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1) First open the [National Enterprise Credit Information Publicity System] website http://www.gsxt.gov.cn/

2) Enter the name of the Chinese company, or a unified social credit code, or registration number search
(must be entered in Chinese, as shown in the figure)
![1381565273054.pichd.jpg](上传中...)

The social credit code is merged on the basis of the business license, the organization code certificate and the tax registration certificate. The codes of the three licenses are collectively referred to as the unified social credit code certificate.
Each Chinese company's business license will have a unified social credit code, the specific location is as follows:
![53ed78e763a949b3b7750593f0378941th.jpg](上传中...)

3) On the search page, the basic information, administrative license information, and administrative penalty information of the enterprise will be displayed. The enterprise will be listed in the business abnormal list information and listed in the list of serious illegal and untrustworthy enterprises (blacklist).






