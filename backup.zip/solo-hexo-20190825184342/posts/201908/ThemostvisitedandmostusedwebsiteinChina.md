title: The most visited and most used website in China
date: '2019-08-08 14:26:56'
updated: '2019-08-17 00:23:46'
tags: [More]
permalink: /articles/2019/08/08/1565245616526.html
---
This article describes some of the more popular websites for Chinese:

**search**

[Baidu](http://www.baidu.com/?tn=50000042_hao_pg)
The world's largest Chinese search engine. Any questions can be entered in Baidu, "Baidu, you will know"

**Social**
[微博](http://weibo.com/)
A bit like the Chinese Twitter, the number of texts is limited to 15 words. Solgan is "finding something new anytime, anywhere."

**shopping**
[淘宝网](https://www.taobao.com/)
China's largest shopping site, it is estimated that more than 70% of Chinese people have bought things in Taobao.

[Free fish] (https://2.taobao.com/)
It is the same company as Taobao and belongs to Alibaba. It is China's largest second-hand idle trading software, only the app version, the web version has been turned off.

**tourism**
[Ctrip.com] (http://u.ctrip.com/union/CtripRedirect.aspx?TypeID=2&Allianceid=1630&sid=924228&OUID=&jumpUrl=http://www.ctrip.com/)
You can buy tickets, train tickets, attraction tickets, book hotels, check travel guides, and book pick-ups.

**video**
[Tencent Video] (http://v.qq.com/)
Use a large number of video sites, including variety shows, movies, TV series and so on.

**Finance**
[Oriental Fortune] (http://www.eastmoney.com/)
The information portal of China's stock market is a professional Internet financial media, providing 7*24 hours of financial information covering A shares, finance, securities, finance, US stocks, Hong Kong stocks, etc.

**news**
[Tencent News] (http://mini.qq.com/)
Tencent's news website. Types include technology, finance, entertainment, sports, cars, fashion... If you want to learn Chinese, you can often check out this website to improve the speed of Chinese reading.

**Fiction**
[Starting point] (http://www.qidian.com/)
Original network literature novel site. Types include fantasy novels, martial arts novels, original novels, online novels, urban novels, romance novels, and youth novels.

**mailbox**
[163 mailbox] (http://mail.163.com/)
China's largest e-mail service provider.

**Recruitment**
[Zhilian Recruitment] (http://www.zhaopin.com/)
China's relatively old job search website was established in 1997.
