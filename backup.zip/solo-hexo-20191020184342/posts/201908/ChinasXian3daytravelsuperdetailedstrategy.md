title: China's Xi'an 3-day travel super detailed strategy
date: '2019-08-09 19:36:08'
updated: '2019-08-19 22:54:30'
tags: [xian]
permalink: /articles/2019/08/09/1565350568777.html
---
## schedule

Day1: Shaanxi History Museum - Big Wild Goose Pagoda - Big Wild Goose Pagoda North Square Music Fountain - Qujiangchi Ruins Park - Datang Ever Sleeping City
Day2: Bell and Drum Tower - Xi'an Ancient City Wall - Yongxing Square - Daming Palace - Huimin Street
Day3: Terracotta Warriors - Huaqing Palace - Lushan

## Day1

Shaanxi History Museum (3h) - Big Wild Goose Pagoda (2h) - Big Wild Goose Pagoda North Square Musical Fountain (1h) - Qujiangchi Ruins Park (3h) - Datang Ever Sleeping City (2h)

### Xias Historical Meseum

In the morning, you can come to the Shaanxi History Museum. This is a good place to learn about Xi'an history and modern changes in Shaanxi. The Shaanxi History Museum must queue up early, or book online in advance, or go to the weekend to have a lot of people. 6,000 tickets per day, free of charge with valid documents to enter, according to the visit situation, it is best to leave half a day to visit Shaanxi Bo is better, at least to stay for 3 hours to visit. The Shaanxi History Museum closed on Monday, stopped the invoice at 16:30 pm, cleared the venue at 17:30, and closed at 18:00.

![null](https://b4-q.mafengwo.net/s1/M00/08/2D/wKgBm04K2c7dtweRAADC1Z1i5w046.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by Solitary Rouge is not alone


![null](https://p2-q.mafengwo.net/s1/M00/08/47/wKgBm04K2diOLYreAADhx93PmzA85.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Xias Historical Meseum

· Located on the northwest side of the Big Wild Goose Pagoda in Xi'an, it is China's first large-scale modern national-level museum. Its completion marks a new development milestone for the Chinese museum industry. · There are more than 370,000 pieces of cultural relics in the collection, ranging from simple stone tools of ancient humans to various kinds of objects in social life before 1840. The time span spans more than one million years. · Among them, the Shang and Zhou bronze wares are exquisite, the Tao dynasty of the past dynasties are numerous and varied, the Han and Tang dynasties are unique in the country, and the tombs of the Tang Tombs are unique in the world. · The museum condenses the essence of the history of the Chinese nation. It is known as the “Chinese treasure treasure house” and is an art palace that displays ancient Chinese civilization and Shaanxi history and culture.


### Da-Yan Tower

From the museum, you can go to the Big Wild Goose Pagoda. The Xi'an Big Wild Goose Pagoda is not only a famous monument, but also a landmark building in Xi'an. Everyone who travels to Xi'an will want to see it. Tickets for the peak season 25 yuan / person, off-season 20 yuan / person. After the walk, lunch can be settled at a nearby mall.

![null](https://p4-q.mafengwo.net/s11/M00/43/31/wKgBEFr2hKWAM-u5AAh6WRj8ipw01.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by 鹤千树


![null](https://p1-q.mafengwo.net/s6/M00/59/60/wKgB4lLtzfKASnJTAAJk_x7Rh8s15.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Da-Yan Tower

· The Big Wild Goose Pagoda was built by Xuan Zang Master himself. Although it has been vicissitudes for thousands of years, it is still intact. It is one of the famous Buddhist towers in China, and is also a unique symbol of the ancient city of Xi'an. · The Big Wild Goose Pagoda is a pavilion-style brick tower. The tower body is made of bricks with a square cone with a staircase spiraling up. There is a vault door in each side of each floor, and the view of Chang'an is unobstructed. · On the south side of the tower, the "Da Tang Sanzang Holy Preface" monument and the "Da Tang Sanzang Holy Preface" monument on both sides of the tower are written by Xuanzang during the Tang Emperor's reign, and they are well preserved. . It is worth mentioning that the Tang Dynasty painters Wu Daozi and Wang Wei had made many murals for the Ci'en Temple, but unfortunately they were already in history. However, on the stone gates and door frames of the four-door cave under the Big Wild Goose Pagoda, there is still a beautiful Tang Dynasty line depiction.


### Big Wild Goose Pagoda North Square Musical Fountain

After lunch, you can go to the Big Wild Goose Pagoda North Square Music Fountain to see the fountain. It is the largest musical fountain in Asia. It is a nighttime illuminating scene. It is the Peugeot landscape of Xi'an. It is a sensory experience that can't be missed in Xi'an. Musical Fountain Time: During the summer (June 10), there will be two performances every day from Monday to Friday (closed on Tuesday during the day) at 12 o'clock and 21 o'clock. On weekends and other national holidays, there will be 5 performances per day, 12, 14 and 16 o'clock. , 18 o'clock, 21 o'clock. In winter (October 9th), there will be two performances every day from Monday to Friday (closed during the day on Tuesday). The specific time is: 12:00, 20:30, and five performances per day on weekends and other national holidays. The specific time is: 12:00, 14:00, 16:00, 18:00, 20:30.

![null](https://b3-q.mafengwo.net/s11/M00/97/BF/wKgBEFsFri2AKYV_AAo7D9ZKAig86.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by new sauce.



![null](https://n1-q.mafengwo.net/s7/M00/00/F7/wKgB6lSen4yALJszAAhGlv9ONpE36.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Big Wild Goose Pagoda Music Fountain

· Located in the North Square of the Big Wild Goose Pagoda, Asia's largest musical fountain, the night is full of brilliance, is the Peugeot landscape of Xi'an. · The fountain is divided into three areas: the 100-meter waterfall pool, the eight-level drop pool and the front-end music pool. It can be divided into independent performances or overall performances. · There are the world's largest square arrays in the eight-level stacked pool. The nozzles can be changed into a variety of water types by arranging and combining. · The large-scale laser water curtain fountain can be fully burned at a height of 6 meters, which is a sensory experience that tourists can't miss.




### Qujiangchi Ruins Park

After watching the music fountain, you can go to the Qujiangchi Ruins Park. The park is an open urban eco-cultural park that integrates historical and cultural protection, ecological gardens, landscapes, leisure travel, folk heritage, and art display. Tickets are free. The public likes to come here for a walk and rowing along the Qujiang pool. In the park, you can also see Shaanxi handicrafts such as paper-cutting and clay sculptures, as well as performances of Qin and Shadow Play.

![null](https://n2-q.mafengwo.net/s11/M00/F7/7A/wKgBEFsZXxWAF5dcAAr3PMK54gM04.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)



![null](https://b3-q.mafengwo.net/s6/M00/8B/1A/wKgB4lOJT4KAO897AArEBds31EQ84.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Qujiangchi Ruins Park

· It was the Royal Royal Court of the Tang Dynasty. Today, many sculptures depicting Tang ancient architecture and expressing the life of the Tang Dynasty have been built. · A comprehensive heritage park integrating ecological reconstruction, sightseeing and leisure, business exhibitions and other functions. · It connects to the Tang Dynasty Furong Garden in the north and the Qin II Shiling Site in the south, covering an area of ​​1,500 mu. The public likes to come here for a walk and rowing along the Qujiang pool. · In the park, you can also see Shaanxi handicrafts such as paper-cutting and clay sculptures, as well as performances of Qin and shadow play.




### Datang Night City

From the park to the evening, dinner can go to Datang Night City, located at the foot of the world-famous Big Wild Goose Pagoda in Qujiang New District of Xi'an, integrating shopping, dining, entertainment, leisure, tourism and business. Going around here in the evening, and then returning to the Youth Hostel, the first day of the trip is over.

![null](https://n3-q.mafengwo.net/s1/M00/4F/66/wKgIC1xjepKABSzJACfbIsEILVk19.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by Winter Wonders



![null](https://b4-q.mafengwo.net/s13/M00/9F/A7/wKgEaVxlEbqAH31pACpLGOh2J_w29.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Datang Night City

Datang never sleeps in the city, shopping, dining, entertainment, leisure, tourism, business. The scenic spot is based on the Big Wild Goose Pagoda. It starts from Xuanzang Square in the north, Tangcheng Wall Ruins Park in the south, Ci'en East Road in the east, and Ci'en West Road in the west. It runs through the three theme squares of Xuanzang Square, Qiguan Cultural Square and Kaiyuan Celebration Square. There are four cultural buildings in the Tang Street District and Xi'an Concert Hall, Xi'an Grand Theatre, Qujiang Film City and Shaanxi Artists Gallery. The Axis Landscape Avenue is a 1500-meter central and sculptured pedestrian street that runs through the north and south. Nine groups of theme groups such as historical figures, hero stories, and classic works of art. The Zhenguan Cultural Square consists of four groups of cultural and artistic buildings: Xi'an Grand Theatre, Xi'an Concert Hall, Qujiang Art Museum and Qujiang Pacific Studios.




## Day2

** Bell and Drum Tower (1h) - Xi'an Ming City Wall (3h) - Yongxing Square (2h) - Daming Palace (3h) - **** Huimin Street (2h) **

### 钟鼓楼

The next morning, I went to the Bell and Drum Tower. The Bell and Drum Tower is a combination of the Xi’an Bell Tower and the Xi’an Drum Tower. It is located in the city center and is the iconic building of Xi’an. The two Ming Dynasty buildings echo each other and are spectacular. Tickets are 35 yuan.

![null](https://b4-q.mafengwo.net/s10/M00/A5/A8/wKgBZ1in5XOAN4x4ABWXvfqIxr874.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)by



![null](https://p2-q.mafengwo.net/s8/M00/E7/AB/wKgBpVUjZV-AXmtnAAm8JhZB7M423.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality %2F90)

## 钟鼓楼广场

· Also known as Shangshu Provincial Plaza, located in the center of Xi'an, with an area of ​​60,000 square meters, second only to Beijing's Tiananmen Square. · It was once the seat of the Shang Tang Shangshu Province, the highest administrative organ that carried out state affairs at that time. · On the east side of the square stands the bell tower with a history of 600 years, and on the west side stands the largest drum tower in the country. · On the north side of the square, there are long-established shops with the prestigious names such as Shengxiang, Defachang, and Wang Haijun; below the square is the Century Golden Flower Shopping Center. · As night falls, the lights of the music fountain, the bell tower and the drum tower illuminate together, which is very spectacular.




### 西安明城墙

After visiting the Bell and Drum Tower, you can go to the Xi'an Ming City Wall. The Ming City Wall is a famous ancient city building in ancient China. It is also the most intact ancient city wall. The sense of history is very strong, and the majestic ancient city wall is extremely magnificent. There are four gates: Dong Chang Le Men, Xi'an Dingmen, South Yongning Gate, Bei'an Yuanmen. The thickness of the wall is greater than the height, and it is as stable as a mountain. The top of the wall can be used for sports cars and drills. Tickets are 54 yuan. It is recommended to go to rent a bicycle and ride around the city wall when you are playing.

![null](https://p1-q.mafengwo.net/s10/M00/A5/AC/wKgBZ1in5XeAd9KcABVTpI2ZnFE41.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by Wendao Four Fire



![null](https://n4-q.mafengwo.net/s11/M00/41/93/wKgBEFty4L2AfJggAA7AhjMBS0U58.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Xi'an City Wall

· Also known as Xi'an Ming City Wall, it is the largest and most preserved ancient city in China. · Together with Pingyao City Wall, Jingzhou City Wall and Xingcheng City Wall, it is the best existing four ancient city walls in China. ·The city wall is surrounded by a moat. The famous Xi’an Bell and Drum Tower is located in the center of the city wall. · Visitors can choose to walk in a leisurely stroll, or choose to cycle around the city gate by bicycle. The road on the gate is not smooth, and the bicycle should be safe.




### Yongxingfang

It must be very hungry after riding a circle on the ancient city wall. Just at lunch time, you can come to Yongxingfang for a big meal. Yongxingfang is one of the 108 squares in Tang Chang'an City. It is located in the northwest corner of Xiaodongmen, close to the city wall. It is a hot food gathering place in recent years, and locals often come to visit. In Yongxing Square, you can not only experience the style of “Tangcheng 108 Square”, but also taste the authentic Shaanxi folk snacks; purchase local products, food and souvenirs processed in the original place and on the spot with old folk crafts.

### Daming Palace

After a meal at Yongxingfang, you can go to Daming Palace. The Daming Palace is the Great Palace of the Tang Dynasty. The political center and national symbol of the Tang Dynasty are the three major palaces of Tang Chang'an City. The largest one in the palace, Taiji Palace and Xingqing Palace is called “East”. Here you can enjoy the restored miniature view of Daming Palace, watch the IMAX 3D film "The Legend of Daming Palace", and experience archaeological excavations and restorations. There are many types of ticket prices in the toll area. Sometimes the ticket service will be introduced and the package will cost 60 yuan. Visitors need to bring relevant documents to use in order to purchase tickets. The scenic area has the south gate and the east gate, the south gate is the main entrance, and the visitor center is also located in the south gate. It is recommended to enter the scenic spot from the south gate.

![null](https://p1-q.mafengwo.net/s5/M00/A4/73/wKgB3FDda_OASzElAAFhnLaW-FA62.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

<div>by JOJO takes you around the world



![null](https://b2-q.mafengwo.net/s12/M00/79/B8/wKgED1vhKg6AZGNnAB5XBeTyAYo79.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Daming Palace National Heritage Park

· It is the most splendid and magnificent building complex in the world-famous Tang Chang'an City “Three Great Inner” (Tai Chi Palace, Daming Palace, Xingqing Palace). · Built in the 8th year of Emperor Taizong of Tang Dynasty, the original palace wall has a circumference of 7.6 kilometers, 11 doors on all sides, and more than 40 sites with proven temples and pavilions. · Enjoy the restored miniature view of Daming Palace, watch the IMAX 3D film "The Legend of Daming Palace", and experience archaeological excavations and restorations.




###回民街

From Daming Palace, go back to the People's Street to eat snacks. This is the gathering place of the Hui people in Xi'an. It is composed of a number of roads. The locals also call it "the Huifang", which is a must-see for Xi'an. There are a variety of snack shops on both sides of the street, you can enjoy the deep cultural heritage while eating food.

![null](https://p2-q.mafengwo.net/s8/M00/4A/79/wKgBpVWuYSyAct8eABv3Cs_IoAE56.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by 墨卿



![null](https://b4-q.mafengwo.net/s10/M00/D3/41/wKgBZ1mAkiqAA7YJABOYfvTz4Eo94.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

##回民街

· The gathering area of ​​the Hui people in Xi'an is composed of a number of roads. The locals also call it the “returning to the square”, which is a must-see for the first time to Xi’an. · There are a variety of snack shops on both sides of the street, you can enjoy the deep cultural heritage while eating food. · Nearly 300 kinds of special flavor snacks such as meat sandwiches, Southeast Asian cakes, clams, and cool skins can be tasted in Huimin Street, making people forget to return. · The street is not very clean, there are many pedestrians, and every holiday is more congested and noisy.




## Day3

** Terracotta Warriors ** (3h) **** - Hua Qing Chi **** (2h) **** - Lushan **** (3h)

### Terracotta Warriors

On the third day, because you want to check out, you can leave your luggage in the Youth Hostel and pick up your luggage when you come back at night. In the morning, I chose to come to Qin Shi Huang Terracotta Warriors and Horses. The Terracotta Warriors and Horses are located in the east of Linyi District, Xi'an City, Shaanxi Province. It is one of the eight wonders of the world. It is a large-scale burial pit in the cemetery of the first feudal emperor Qin Shihuang of Zhengzhou. The museum is based on the Terracotta Warriors and Horses of Qin Shihuang. The ruins museum built on the original site of the Terracotta Warriors and Horses is also the largest ancient military museum in China. Tickets cost 120 yuan, far from the city can be 5 free rides at the train station.

![null](https://p2-q.mafengwo.net/s10/M00/F6/02/wKgBZ1ioWQGAa5Y4ABayM-ADjsU22.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90) by Wendao Four Fire



![null](https://n3-q.mafengwo.net/s1/M00/07/27/wKgBm04K2X3qUO3yAADrb72LkHI66.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Qin Shi Huang Terracotta Warriors and Horses Museum

· It is the largest ancient military museum in China built on the original site of a large-scale burial pit in the Qin Shihuang cemetery. · There are 3 terracotta warriors. The No. 1 pit is the main force of the chariot and the infantry. There are about 6,000 life-size pottery figurines. The second pit is a mixed group of chariots, cavalry, and squadrons. The third pit is the command system of the military array. · Unearthed terracotta warriors and horses are divided into generals, warriors, and taxis. The facial features of each pottery vary. Originally there were painted, but most of them have faded due to fire and soaking. · The bronze horses and horses exhibited in the bronze horse and horse exhibition hall, using a lot of gold and silver, are exquisitely crafted and known as the “Bronze Crown”, which is of great value to the academic research of the Qin Dynasty.




### Huaqing Palace

In the afternoon, you can go to Huaqing Palace and Lushan Mountain, and now it has become an attraction to play with. The Huaqing Palace (Huaqingchi·Lushan) is home to the Tang Yu Tang Site Museum, the site of the Xi’an Incident – ​​the five halls, the Jiulong Lake and Furong Lake Scenic Area, the Tangliyuan Site Museum and other cultural districts, and the Feishuang Hall, Wanshou Hall and Changsheng. The iconic buildings such as the Temple, the Ring Garden and the Palace of the Kings. High season: 150 yuan, 120 yuan in the off season. It is strongly recommended that the large-scale real-life historical dance drama "The Song of Everlasting Sorrow" (only available in April-October), local friends in Xi'an are full of praise. Returning from the Huaqing Palace to the urban area, you can find some snacks in the city now, and then go to the Youth Hostel to take your luggage. This trip to Xi'an has come to an end.

![null](https://n2-q.mafengwo.net/s12/M00/EB/35/wKgED1vn2HmAJoAoAB0dpt4FtI488.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)by Bei Xiaoxian

## Huaqing Palace

· Huaqing Palace has been a resort for royal bathing since ancient times. It is said to have been the place where Yang Guifei bathed. According to legend, Zhou Youwang of the Western Zhou Dynasty once built an official here. · There are relatively complete cultural relics such as Zhou, Qin, Han, Tang, Ming and Qing dynasties, garden landscapes, ancient buildings and ancient and famous trees. · Especially the love story of Tang Minghuang and Yang Guifei and the "Xi'an Incident" that shocked China and foreign countries. The Qin, Han, and Yi dynasties successively built them, and they were built several times in the Tang Dynasty.
</div>
