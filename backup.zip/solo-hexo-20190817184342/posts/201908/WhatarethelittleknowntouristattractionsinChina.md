title: What are the little-known tourist attractions in China?
date: '2019-08-09 12:57:24'
updated: '2019-08-09 23:05:56'
tags: [Tour]
permalink: /articles/2019/08/09/1565326644471.html
---

### Tengchong Heshun: 
It is a famous hometown of overseas Chinese in Yunnan Province, China.
**Best travel time**
The best in the middle and late April, when the rape blossoms are in full bloom.
![null](https://pic1.zhimg.com/80/9d9a8a1d711f7a6d46f14ba7a75f9671_hd.jpg)

### Weng Ding: 
The last primitive tribe in China is a historical and cultural village in Yunnan Province.
![null](https://pic3.zhimg.com/80/c02413430991f0b6a40acec80a6ee5d6_hd.jpg)

### Mengzi: 
Located in the southeast of Yunnan Province, it is the core area of ​​the central city of Weinan.
![null](https://pic4.zhimg.com/80/1d537e0230fb256e3a887960e6a25cf0_hd.jpg)
French station in Mengzi, China


### Ba Mei: 
Also in Yunnan Province, it is the last paradise, hidden in the village inside the cave.
![null](https://pic3.zhimg.com/80/52c6656d9fabe84918a887674359438e_hd.jpg)


### Chaka Salt Lake: 
Located in Qinghai Province, it was named one of the 55 places that must be visited by the National Tourism Geography Magazine. The time here seems to be static, giving everyone a pure dream.
![null](https://pic3.zhimg.com/80/1c333693782c18cf8bfe27939f987949_hd.jpg)

### Yunfeng Bazhai Army:
Located in Anshun City, Guizhou Province, to explore the military area of ​​the ancient Ming Dynasty in China
![null](https://pic4.zhimg.com/80/2d8250f0198193f0f28300f9d432e95b_hd.jpg)

### Zhongdong Miao Village 


- located in Guizhou Province. Nongdong Miao Village was named "China's last burrowing tribe". This cave of more than 100 meters wide and more than 200 meters deep lives in China's last burrowing "tribe" - a total of 73 Miao people from 18 households. Their ancestors moved to the mountains to escape the war and settled in the cave.
![null](https://pic3.zhimg.com/80/f419e59fc7d435a0ee6998a6e9d7c1ef_hd.jpg)
![null](https://pic3.zhimg.com/80/80a7c316be0f2ca2c8ac057accf0446e_hd.jpg)



Source:
Https://www.zhihu.com/question/19855515/answer/25401729
