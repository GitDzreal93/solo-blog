title: A delicious restaurant in Hong Kong, China, like a local, playing in Hong Kong
date: '2019-08-09 21:57:03'
updated: '2019-08-21 17:40:22'
tags: [HongKong]
permalink: /articles/2019/08/09/1565359023002.html
---
## Their home pineapple oil is lemony: Kang Nian Restaurant

There are thousands of Hong Kong tea restaurants, and the most recommended tea restaurants are: Tsui Wah, Tai Hing; where to go where to eat on the streets, this time in Hong Kong, there is no intention to find another Hong Kong-style super authentic tea restaurant: Kang In the restaurant of the year, I heard that this Kangnian restaurant is also one of Tan Qilin’s and Tan’s heart.
Located in Mong Kok, the Connaught restaurant near the Prince is in the middle of the super-long bridge that the rest of the most famous weekend is the rest of the Philippines. Take a photo of the port in Mong Kok, buy and buy on the street, and take a break and drink by the way. A cup of frozen milk tea, point to pineapple oil, feel the ordinary every day of Hong Kong people.

![null](https://b1-q.mafengwo.net/s12/M00/E7/10/wKgED1wOIyKAC7tpACA_zk4fuAw55.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

 Hong Kong tea restaurant, if there is no place or you are a meal or two, the clerk will usually arrange a "set up" that is the table, to arrange more people to eat. (If you don't want to fight the table, you may have to wait for it)

![null](https://p3-q.mafengwo.net/s12/M00/E7/2F/wKgED1wOIzCAQeY5ACPME8KJ-G094.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Tea restaurants generally have breakfast, regular meals, afternoon tea, special meals, or the same day. Although the menu type has all the food introductions, it is more cost-effective to eat the package.
Hong Kong people who love to drink 3: 30-afternoon tea, after 2 pm or 2:30 pm, the afternoon tea set is also very cost-effective.
  

### 特餐A: Eggplant fresh beef powder with slippery egg + half serving Western toast with frozen milk tea

The name of the Hong Kong tea restaurant is very straightforward. The special meal is a tomato boiled beef macaroni. It can be said that the tea restaurant must have one of the foods. The package will usually be accompanied by a slippery egg + Western Toast. Choose coffee or milk tea, you can also add money for other drinks, frozen drinks are subject to an additional charge.

![null](https://n1-q.mafengwo.net/s12/M00/E7/6C/wKgED1wOI0mAGX0UAB9y01bEepI79.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://n4-q.mafengwo.net/s12/M00/E7/6E/wKgED1wOI0qAF5IxABoy-LaCknA03.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

I love to eat the bottom of the tomato soup. This is a must. The tomato soup is rich in the base, the fresh beef is tender and smooth, and the macaroni is soft and moderate. With the slippery egg and the West Toast, it is just a different taste. Hong Kong cuisine.
  
  

### Fresh shrimp hibiscus egg + frozen milk tea

Another authentic dish in the tea restaurant: dish-headed rice, which means that both the dish and the rice are served on the same plate, to be fast. Working office workers usually choose the dish served on the same day, serving fast and cheap.

![null](https://b4-q.mafengwo.net/s12/M00/E7/E7/wKgED1wOI4OAECIvABytcyGu5rs60.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

First of all, this dish is full of food, and the amount of food for boys is very much! (extra large amount of rice wrapped under the egg)
The fresh shrimp fried egg on the surface, in fact, not only fresh shrimp but also Hong Kong-style pork roast, each mouth has shrimp and meat and eggs! Meet three wishes at once!
   

### Hainan Chicken Rice Set + Frozen

Although Hainanese chicken rice is best known in Hainan or Malaysia, Singapore, Hong Kong is also very keen on this Hainanese chicken rice, and the taste is basically and local.

![null](https://n3-q.mafengwo.net/s12/M00/E8/16/wKgED1wOI56APsMJABd9fEQhYTA78.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

A bowl full of chanterelle rice will not have a greasy feel. The Thai fragrant rice has distinct grains and is served with ginger onions or Thai sweet and sour sauce.
Also, there is a soup with old fire, although it is a daily soup, carrots and pork bones, full of materials, to ensure that there is no MSG!
  
  

### Today's Best: Lemon Flavored Pineapple Oil

Hong Kong pineapple oil is famous, this is everyone knows, the bread of this Conifer restaurant should also be very popular, there is a take-away service directly outside the shop, go by and buy one to eat, great!

![null](https://b1-q.mafengwo.net/s12/M00/E8/4E/wKgED1wOI7SANMhgABYpfODZy5o75.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Freshly baked pineapple oil, the meringue on the surface is crispy, and a little lemon scent is added to the pineapple bag, which just neutralizes the greasy feel of the extra thick butter in the bread.
Boss, I want to have another one!
Frozen milk tea, this milk tea, the bottom of the tea has no bitter taste, praise; milk + tea will not be a too strong match, will not be sweet and greasy when going to the ice, or because the bottom of the tea will be flustered!

**Tips:**
Most tea restaurant hot milk tea is on the sugar-free version, so there will be a lot of white sugar on the side of the cooking area. I don't want to drink the milk that is very original and bitter. The pottery friends remember to order frozen milk tea!

Per capita: HK$65
Address: G/F, 143-145 Tung Choi Street, Prince Edward, Hong Kong
Business hours: 06:30-03:00 throughout the year
Phone: +8522391 8398
  
  
  
  

## Brunch time: URBAN Cafe Commune

In Hong Kong, tea restaurant pineapple oil, restaurant snacks, convenience store curry fish eggs, eating too much choice.

![null](https://b2-q.mafengwo.net/s12/M00/E8/D6/wKgED1wOI_qAcodcAB1bEpUDv0s92.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

If you don't want to get up early, just go shopping, URBAN in New Century Plaza can satisfy your sense of leisure. In addition to the noon, dinner period need to line up, the time outside the meal is generally not queued, at least we do not need to wait for two times.

![null](https://p3-q.mafengwo.net/s12/M00/E9/24/wKgED1wOJByAfF8yAB9-GzA_LTw50.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

This restaurant located in the atrium of the second floor of the shopping mall, I think the special feature is that the food shop + retro movie decoration style that will be seen when you look up is particularly attractive. Meal menus offer different dishes.
  

### One of the main dishes: URBAN 3 hours slow-boiled chicken with salad + chips

![null](https://p4-q.mafengwo.net/s12/M00/E9/5B/wKgED1wOJDiAKURuAB61rw4gL3w38.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The overall selling is good, the meat is tender and juicy, and there is a small disadvantage that a quarter of the chickens are more troublesome to eat.
  
  

### 63°温泉蛋卡邦尼肉肉粉粉

![null](https://n2-q.mafengwo.net/s12/M00/E9/81/wKgED1wOJFGAI9LoAB8n-0BQcXk15.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Hot spring eggs are very attractive. The half-cooked egg yolks are cut open and mixed with spaghetti. The egg and bacon are very good.
  
  

### 卜卜脆炸炸鱼堡

![null](https://p3-q.mafengwo.net/s12/M00/E9/EB/wKgED1wOJJ2AT45MAB5FjoXG88850.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The fried fish is served hot, the fish has no astringency, and there is no greasy feeling of deep-fried.
  
   

### Italian North Gusong Truffle Rice

![null](https://b3-q.mafengwo.net/s12/M00/EA/06/wKgED1wOJK6AU45ZAB2v9k_5P-838.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Although stewed rice, but the rice is hard, we have replaced it because of this hard rice, but it is still the same, so I will not comment.

![null](https://n4-q.mafengwo.net/s12/M00/EA/1E/wKgED1wOJLmAQSG9ACKCJAcj7ko76.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

* Packages are served with frozen peach tea or soda.
   
Address: Shop 121, L1 Floor, New Century Plaza, 193 Prince Edward Road West, Mong Kok
Opening hours: 08:00-23:0
  
  
  

## Upstairs good retro ice room: Mong Kok Starbucks

Starbucks, a large chain of Starbucks coffee shops, is certainly not unfamiliar. Starbucks, which specializes in-store design, also opened a retro Starbucks limited store on the streets of Mong Kok, Hong Kong.

![null](https://n4-q.mafengwo.net/s12/M00/EA/E7/wKgED1wOJR6AJlodABwiCtMf8HM60.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://b1-q.mafengwo.net/s12/M00/EA/E9/wKgED1wOJR-AYs9WACCHpGjKarw12.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://b1-q.mafengwo.net/s12/M00/EA/EB/wKgED1wOJSCACHEUAB3MyR1q-Qc18.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Just looking at the signboard outside will feel the same as the ordinary upstairs shop, but when you look closer, the murals starting from the stairs are from the street graffiti who claimed to be "Kowloon Emperor".
  
The design of the second and third floors uses Hong Kong's old style, from the Hong Kong-style ice room tables and chairs, hand-painted menus, to retro movie poster collages on the walls, all revealing the designer's intentions.

![null](https://n4-q.mafengwo.net/s12/M00/EB/1A/wKgED1wOJTuALcoyACP-wZgDWLk02.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://n3-q.mafengwo.net/s12/M00/EB/1C/wKgED1wOJT2AGLbEACoBvu-iZjc16.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://n1-q.mafengwo.net/s12/M00/EB/1E/wKgED1wOJT6AXTxJAB_Nzu3cD3Y94.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

What is even more surprising is that in addition to the regular sale of regular coffee drinks, there will be a Hong Kong tea restaurant menu: chicken, egg tart, pineapple oil... with coffee, this is Hong Kong.

![null](https://b4-q.mafengwo.net/s12/M00/EB/52/wKgED1wOJVaAMy1gAClOPJbSTv429.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://p1-q.mafengwo.net/s12/M00/EB/54/wKgED1wOJVeAHbC5ACQbDPYHBBU05.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The retro Starbucks in Mong Kok, in addition to coffee, is also a cultural exchange site to promote Hong Kong's local culture and art, and occasionally hold exhibitions and sharing sessions in the store.

![null](https://p3-q.mafengwo.net/s12/M00/EB/57/wKgED1wOJViAHtDIAB4DNWU3B8068.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://n3-q.mafengwo.net/s12/M00/EB/5E/wKgED1wOJVqAawh_AClF_SNggZ400.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

In this place, like a second to enter the old Hong Kong, buy a cup of coffee, quietly for an afternoon, is also very freehand.

[source](/https://www.mafengwo.cn/gonglve/ziyouxing/203968.html)
