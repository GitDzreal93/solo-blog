title: Hong Kong instgram photo must go to the place!
date: '2019-08-09 19:44:17'
updated: '2019-08-22 18:26:36'
tags: [HongKong]
permalink: /articles/2019/08/09/1565351057041.html
---
## Graham Street graffiti

![null](https://p4-q.mafengwo.net/s12/M00/34/BE/wKgED1wkMsWAO56VAAKJb32GnsA10.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

This place star has a high rate of appearance! Many international artists often appear in this photo, without worrying about the monotony of color. If you accidentally "get lost", you will be immersed in the color. It is a fashion blockbuster to wipe the card with your hand.

![null](https://p3-q.mafengwo.net/s12/M00/34/BF/wKgED1wkMsaASOe8AAGAyDfRyd425.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Many murals reflect the old Hong Kong style, and you can make a film in the background. Many lanes are narrow and have many slopes and stairs. It is recommended that you wear comfortable shoes when you go to the home, or you will be tired like climbing a mountain.

![null](https://b1-q.mafengwo.net/s12/M00/34/C0/wKgED1wkMseATwFFAAKG0poie5Q72.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

### Address:

Intersection 48, Hollywood Road, Central, 46 and Graham Street, Central

### traffic:

MTR Central Station D1/D2 exit





## 嘉咸街Graham Street

· Located in the middle section of Hollywood Road, Central, Hong Kong. It is the characteristic of the downtown area since the fall of the road. · The open-air market in Graham Street is said to be one of the oldest open-air markets. There are a variety of small vendors on the street, along the two sides of the upstairs stairs. · The highest rate of appearance is the graffiti wall of Jiaxian Street. With the background of the Kowloon Walled City, the city's appearance is vividly depicted, which is very suitable for taking pictures.



## 东坝防缇Dongba Flood Control

![null](https://p3-q.mafengwo.net/s12/M00/34/C1/wKgED1wkMsiANXjTAAO3v6uLdyg00.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

This is Ivy, I often want to shoot! I can't help it all at all. If I don't punch the card once, I feel that I am not cool enough. It is a secret base!

![null](https://b1-q.mafengwo.net/s12/M00/34/C5/wKgED1wkMsmAMtUOAAE6UT8YxAA48.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

It is very suitable for a person to run on the embankment to think about life. While blowing the sea breeze, feel the ebb and flow, really knocking on the enjoyment, the sea is very blue, the blue drops are the same as the one above the movie, just climb up and take a picture. Zhang is a big movie.

![null](https://p3-q.mafengwo.net/s12/M00/34/C8/wKgED1wkMsqADRx_AAGo7XpKcbE80.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

However, after all, climbing on the embankment is dangerous, and some dangerous actions suggest that you do not do it casually. In an international metropolis, there is such a place very very rare! When you haven’t been punched by too many people, let’s take it first!

![null](https://p4-q.mafengwo.net/s12/M00/34/CA/wKgED1wkMsuAZ0CBAAHnf5Sp3Yg97.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

### Address:

New Territories Sai Kung

### Super detailed traffic

**Diamond Hill Departure: ** MTR Diamond Hill Station Exit C2, take Bus No. 92 to Sai Kung City Centre; then take bus No. 94 in the direction of Wong Shek Pier and get off at Pak Tam Chung Station;
** Departure on Sunday or public holidays: ** MTR Diamond Hill Station Exit C2, take bus No. 96R towards Wong Shek Pier and get off at Pak Tam Chung Station.
** Depart from Sha Tin: ** Bus Terminal, New Town Plaza, Shatin City Centre, take bus No. 299X to Sai Kung City Centre; transfer to Bus No. 94 in the direction of Wong Shek Pier and get off at Pak Tam Chung Station.

## Weiye Street Footbridge

![null](https://p4-q.mafengwo.net/s12/M00/34/CB/wKgED1wkMsyALI0YAAG0oKEIgps57.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Correct! It's just a bridge! The classic Hong Kong film "Zhi Ming and Chun Jiao" made it a place where Zhang Zhiming and Yu Chunjiao, the first time they chatted together, began to develop their relationship.

![null](https://b4-q.mafengwo.net/s12/M00/34/CC/wKgED1wkMsyAeuKkAAB95QtkDCk14.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

After that, it became a lot of net red lady punch card holy place. The long bends in the corridors here are not at the end, and the framed window flashes the sunlight.

![null](https://p2-q.mafengwo.net/s12/M00/34/CD/wKgED1wkMs2AVxvlAAE4h3OoHFY84.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Much like the slaps and temptations of the men and women who are endless in the shackles, the director can only say that the director is talented.

![null](https://b2-q.mafengwo.net/s12/M00/34/CF/wKgED1wkMs6AZBdsAAF562fd6yo66.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

How to take the mirror to get the most out of it, you have to rely on your heart.

![null](https://p3-q.mafengwo.net/s12/M00/34/CF/wKgED1wkMs-AFXVRAADtKsBsdQs14.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

### Address:

Near Kwun Tong Industrial Area

### traffic:

Kwun Tong MTR Station Exit C

## Rainbow Village

![null](https://n2-q.mafengwo.net/s12/M00/34/D0/wKgED1wkMs-AAEtQAANHRSl2wSI00.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

This is a Hong Kong photo-taking place where the literary youth who are obsessive-compulsive people will ring the "squeaky" thunderous applause. In the same color as the rainbow, you can also shoot a vintage blockbuster in the style of Wes Anderson.

![null](https://b3-q.mafengwo.net/s12/M00/34/D3/wKgED1wkMtCAUUSCAAVxmLSzWyc80.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Advise you to come with more than a few charging treasures mobile phone memory and leave more or not enough!

![null](https://b2-q.mafengwo.net/s12/M00/34/D4/wKgED1wkMtGALD6yAAH4l6REVRY34.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

### Address:

Rainbow Village, Wong Tai Sin, Kowloon

### traffic:

MTR Rainbow Station C4 Exit

[source](https://www.mafengwo.cn/gonglve/ziyouxing/230836.html)
