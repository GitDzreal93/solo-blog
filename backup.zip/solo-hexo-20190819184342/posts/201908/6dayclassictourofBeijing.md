title: 6-day classic tour of Beijing
date: '2019-08-09 16:49:30'
updated: '2019-08-18 13:04:14'
tags: [beijingtour]
permalink: /articles/2019/08/09/1565340570778.html
---
### Route overview
D1 Tiananmen Square (1.5 hours) → Qianmen Street (1.5 hours) → Beijing Quanjude (Qianmen) (1 hour) → Forbidden City (3 hours) → Jingshan Park (1 hour)

D2 Temple of Heaven Park (2.5 hours) → Lama Temple (2 hours) → Confucius Temple and Guozijian Museum (1.5 hours) → Guijie Street (2 hours)

D3 Prince Gongfu (2.5 hours) → Shichahai (3 hours) → Nanluoguxiang (motorized choice, 1.5 hours) → Shichahai Bar Street (2 hours)

D4 Yuanmingyuan (3 hours) → Tsinghua University (2 hours) → Bird's Nest (1 hour) → Water Cube (1 hour)

D5 Summer Palace (4 hours) → Peking University (2 hours)

D6 Badaling Great Wall (3-4 hours) → Ming Tombs (2 hours)






### Day1 play guide
##### morning
In the morning, head to Tiananmen Square to experience the solemnity of the world's largest square. (If you want to see the flag, you must catch up early, because the flag-raising time is the same as the sunrise time, so you must check the information in advance, at least one hour before you arrive.) After watching the Heroes Monument, the Chairman Mao Memorial Hall, the Great Hall of the People and other buildings, You can go around the front door and feel the style of the old Beijing shopping street. By the way, have lunch here.

Tiananmen Square (1.5 hours) 15 minutes walk Qianmen Street (1.5 hours) 5 minutes walk Beijing Quanjude (Qianmen) (1 hour)



##### Tiananmen Square
Tiananmen Square
One of the representative attractions of Beijing tourism, where you can watch the flag, there is also the Monument to the People’s Heroes, Chairman Mao Memorial Hall.
[![null](http://p1-q.mafengwo.net/s9/M00/5D/C6/wKgBs1bwDfCAIkuCAAr8itczKQo18.jpeg?imageMogr2%2Fthumbnail%2F%21270x180r%2Fgravity%2FCenter%2Fcrop%2F%21270x180%2Fquality%2F100)


##### Qianmen Street
Qianmen Street
One of the most famous old streets in Beijing, there are many old shops for hundreds of years, and there are sightseeing cars on the pedestrian street.
[![null](http://p3-q.mafengwo.net/s11/M00/0D/E5/wKgBEFq5qTqAIrrAADf0O4MRO2M97.jpeg?imageMogr2%2Fthumbnail%2F%21270x180r%2Fgravity%2FCenter%2Fcrop%2F%21270x180%2Fquality%2F100)


##### Beijing Quanjude (Qianmen)
Beijing Quanjude (Qianmen)
[![null](http://b3-q.mafengwo.net/s7/M00/A1/DE/wKgB6lQGtfGAE6pfAAz8JTBP7Ak22.jpeg?imageMogr2%2Fthumbnail%2F%21270x180r%2Fgravity%2FCenter%2Fcrop%2F%21270x180%2Fquality%2F100)


in the afternoon
After lunch, you can take the bus back to the Tiananmen Gate and start the afternoon tour of the Forbidden City. The Forbidden City area is relatively large, there are many sightseeing spots, it is best to do some homework before the tour, or follow the tour guide to explain. From the north gate of the Forbidden City, you will come to Jingshan Park. You can see the panoramic view of the Forbidden City and the 360-degree view of Beijing without a dead end. If you still have physical strength, you can go around the hutongs at dusk and feel the most authentic city life in Beijing.
Forbidden City (3 hours) 5 minutes walk Jingshan Park (1 hour)

##### Forbidden City
Forbidden City
The most intact and largest wooden structure in China and the world, where you can experience the inheritance of Chinese civilization.
![null](http://n4-q.mafengwo.net/s1/M00/6F/50/wKgIC1xWmuKAIRc8ABvON1lfBS461.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Jingshan Park
Jingshan Park
Located on the central axis of Beijing, it was once the commanding height of the city, overlooking the Forbidden City
![null](http://b3-q.mafengwo.net/s11/M00/A8/2A/wKgBEFt4rEGAI5dYAENQOfwdpe829.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Traffic strategy
As the capital, Beijing's urban transportation is very developed. Metro and public transport are the most common means of travel for tourists. After arriving in Beijing, it is strongly recommended to set up a [Municipal Traffic Card] in the subway station. Metro, public transport and some city fast rails can be used for card swiping.

Today's traffic is mainly done by foot. After visiting the front door - Dashilan, if you want to go back to the Forbidden City near the Tiananmen Gate, you can take the 2/59/120 bus from Dashilan Bus Station and get off at Tiananmen East Station.

##### Dining guide
Beijing has been a cosmopolitan city where ethnic groups live together for centuries. Therefore, the snacks here are also self-contained, salty and sweet. Although Beijing cuisine is not included in the eight major cuisines, the reputation of Beijing cuisine has long been circulated, and the delicious flavor is the common feature of Beijing cuisine.

Qianmen Street has a lot of old shops like Quanjude and Donglaishun and other Beijing cuisine. The restaurants are always full of people. Next, to the Dashilan alley, there are a lot of special snacks. If you want to eat fried food, stewed food, etc., it’s right to visit here.

##### Accommodation guide
Tiananmen Square - Forbidden City - Qianmen - Wangfujing is the central area of ​​Beijing, with a large number of hotels of various grades. Many of Beijing's popular attractions are also located in the above areas and can be easily reached. Also, Metro Lines 1 and 2 pass through the area, making it easy for tourists to travel.
Accommodation
Around Tiananmen Square
Accommodation
Around Tiananmen Square
29% will live in the neighborhood around Tiananmen Square
There are 203 hotels. This is the most central part of Beijing, with the symbol of Beijing - Tiananmen Square, the Forbidden City. Staying near here, you can walk to Tiananmen Square, you can...


### D2 play Raiders
##### morning
I went to the Temple of Heaven this morning to visit the four entrances and exits in the southeast and northwest. It is recommended to enter from the south gate and the north gate. This way, you can visit the order of the Qiuqiu, Echo, and the Hall of Prayer to get the best experience.
Temple of Heaven Park (2.5 hours)

##### Tiantan Park
Tiantan Park
The Emperor of the Ming and Qing Dynasties worshipped the god of heaven and earth and prayed for the harvest of the grain.
![null](http://p2-q.mafengwo.net/s9/M00/50/C0/wKgBs1dZeKGADt4MAAlCKUhzg3A52.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


in the afternoon
In the afternoon, visit the Lama Temple. As the largest Tibetan Buddhist temple in Beijing and the former residence of Emperor Yongzheng, the popularity and extravagance of the Lama Temple is unmatched by other Buddhist temples and is worth seeing. After visiting the Lama Temple, you can go to the Confucius Temple Guozijian across the street. It is highly recommended to follow the tour guides. Otherwise, many details cannot be fully understood on your own.
Lama Temple (2 hours) 8 minutes walk Confucius Temple and Guozijian Museum (1.5 hours)

##### Lama Temple
Lama Temple
The best-preserved Lamaism in Beijing
![null](http://b2-q.mafengwo.net/s11/M00/44/9C/wKgBEFtGKyaAGcuvAF8nHEhBSnM69.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


Confucius Temple and Guozijian Museum
Confucius Temple and Guozijian Museum
The building is antique and the atmosphere is extremely strong.
![null](http://b3-q.mafengwo.net/s10/M00/89/EF/wKgBZ1kYJSyAbTv4ABVfw9kHwDg11.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)

**at night**
After visiting the sights, you can come to the big street near the street for dinner. It is full of delicious food from all over the country, with spicy flavors, and each has its signature dishes. When you are playing in the middle of the night, the lively streets are full of lights, and you will feel the other charm of Beijing.
Guijie Street (2 hours)
##### Gui Street
Gui Street
On a street less than 1 kilometer long, a series of restaurant restaurants, including hot pots, barbecues and other flavors of Sichuan, Shandong, Guangdong, and Hunan.
![null](http://b2-q.mafengwo.net/s9/M00/AF/CE/wKgBs1hnrQmAeDmtAAru6B-tNj417.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)

Traffic strategy
Today's itinerary transportation is mainly done by subway. If you go to the Temple of Heaven to play, Metro Line 5 can exit at Exit A2 of Tiantan East Gate Station. After the end of the Tiantan journey, you can continue to take Metro Line 5 to the Lama Temple Station, and Exit C will be the attraction. Other trips on that day can be completed on foot.


##### Accommodation guide
Tiananmen Square - Forbidden City - Qianmen - Wangfujing is the central area of ​​Beijing, with a large number of hotels of various grades. Many of Beijing's popular attractions are also located in the above areas and can be easily reached. Also, Metro Lines 1 and 2 pass through the area, making it easy for tourists to travel.
Accommodation
Around Tiananmen Square
Accommodation
Around Tiananmen Square
29% will live in the neighborhood around Tiananmen Square
There are 203 hotels. This is the most central part of Beijing, with the symbol of Beijing - Tiananmen Square, the Forbidden City. Stay near here and walk to Tiananmen Square.


### D3 play Raiders
morning
In the morning, I went to the "China's largest corrupt official" and the residence of Gong's Mansion, the Prince's Mansion. The layout of this mansion is even higher than the specifications of the Forbidden City. It is recommended to follow the tour guide to explain the details, otherwise, you will miss many interesting stories and details.
Prince Gong's Mansion (2.5 hours)

##### Prince Gong's Mansion
Prince Gong's Mansion
The most complete preserved palace in the Qing Dynasty in China
![null](http://b4-q.mafengwo.net/s11/M00/CC/A0/wKgBEFqqyYGAI7PbAAvIIp4Q8qQ28.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


in the afternoon
After lunch, you can go to Shichahai to play. There are many small attractions here, and the former residence of Soong Ching Ling and the former residence of Guo Moruo are located here. You can also go to Yantai Street to experience the deep market style and rich old Beijing characteristics. Going northeast, you can see the landmark building in Beijing, the Bell and Drum Tower. If you don't feel tired, you can go to the crowded Nanluoguxiang. The alleys on both sides of the alley have a lot to say. In the evening, you can enjoy the evening scenery in the Houhai. If you are interested, you may wish to experience the bar culture here.
Shichahai (3 hours) 5 minutes walk Nanluoguxiang (motorized choice, 1.5 hours) 10 minutes walk Shichahai Bar Street (2 hours)

##### Shichahai
Shichahai
Traditional and avant-garde in the heart of Beijing’s nightlife
![null](http://p2-q.mafengwo.net/s11/M00/CF/1B/wKgBEFqaQ66AYwBtAAJfn49nBRY19.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Nanluoguxiang
Nanluoguxiang
The most affluent old Beijing-style hutong street, global tourists love to come here to "lost Beijing"
![null](http://n4-q.mafengwo.net/s13/M00/B5/4E/wKgEaVxmE4-AMWNBAEqOy1UYmaA58.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Shichahai Bar Street
Shichahai Bar Street
The most prosperous, ancient and modern atmosphere of the bar street in Beijing
![null](http://p2-q.mafengwo.net/s6/M00/1D/7A/wKgB4lMykZeATcG2AAD8TfYZXOs09.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)

Traffic strategy
Prince Gong's Mansion is located on the west side of Shichahai. After getting off at Beihai North Station of Metro Line 6, walk 300 meters to the north.
Shichahai-Zhonggulou-Nanluoguxiang can be completed on foot. The area can also take a human tricycle tour, the coachman will take you around the hutong, and talk about the old Beijing story. The regular manpower tricycle has a service price list that lists the itinerary, the time of the tour and the cost per visitor.


##### Accommodation guide
Tsinghua University-Zhongguancun is the education/science center of Beijing, with convenient transportation. Metro Line 4 and several bus lines meet here. In addition to many well-known universities, there are also attractions such as the Summer Palace and Yuanmingyuan. The second half of Beijing is recommended to stay here.
Accommodation
Tsinghua University, Zhongguancun
Accommodation
Tsinghua University, Zhongguancun
9% will live in Tsinghua University, Zhongguancun District
There are 332 hotels. Zhongguancun is Beijing's “Silicon Valley”, the digital industry is very developed, and various products are also sold very cheaply.


### D4 play Raiders
##### morning
The Yuanmingyuan Scenic Area is large, so it is best to take half a day to play. The scenic spots in the park mainly include the cultural landscape in the east.
![null](http://b3-q.mafengwo.net/s10/M00/6B/9D/wKgBZ1nss-mALxmeAA19vw2CuDs14.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### in the afternoon
If you go to Tsinghua University, it is best to enter from the West Gate of the school, so you can rent a campus bike, which is convenient and effortless to visit all corners of the campus. Recommended tour route: Tsinghua West Gate - Hetang Moonlight - Shuimu Tsinghua - Grand Auditorium - Tsinghua School - Second School Gate - Tsinghua West Gate.
Tsinghua University (2 hours)

##### Tsinghua University
Tsinghua University
One of the highest schools in China, the students are fascinated
![null](http://p2-q.mafengwo.net/s11/M00/D3/E5/wKgBEFsgnEKAOp9EAAScMCE_PME00.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)
Evening (motorized choice)
If you still have physical strength, you can come to the Bird's Nest/Water Cube to enjoy the night view at night. It should be noted that these two attractions are not open to the public at night and can only be viewed from the outside.
Bird's Nest (1 hour) 8 minutes walk Water Cube (1 hour)

##### Bird's nest
Bird's nest
The space structure is novel, the building structure is integrated, and it has a strong impact and visual impact.
![null](http://p1-q.mafengwo.net/s11/M00/87/0E/wKgBEFs0-RiARGItAASTSl_waDU87.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Water Cube
Water Cube
A multi-functional center that combines swimming, sports, fitness, and leisure. It has a unique shape.
![null](http://n2-q.mafengwo.net/s13/M00/AC/DA/wKgEaVzRSU6AL8VrAA71HidupP860.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Traffic strategy
To Yuanmingyuan, you can take the subway line 4 and get off at Yuanmingyuan Station.
If you go to Tsinghua University, you can start from Yuanmingyuan Subway Station and walk about 400 meters to the east. You can also take the school bus in the school and get on the bus for 2 yuan.
Go to the Bird's Nest / Water Cube and take the subway line 8 and get off at the Olympic Sports Center Station.


##### Accommodation guide
Tsinghua University-Zhongguancun is the education/science center of Beijing, with convenient transportation. Metro Line 4 and several bus lines meet here. In addition to many well-known universities, there are also attractions such as the Summer Palace and Yuanmingyuan. The second half of Beijing is recommended to stay here.
Accommodation
Tsinghua University, Zhongguancun
Accommodation
Tsinghua University, Zhongguancun
9% will live in Tsinghua University, Zhongguancun District
There are 332 hotels. Zhongguancun is Beijing's “Silicon Valley”, the digital industry is very developed, and various products are also sold very cheaply.


### D5 play Raiders
Today's itinerary is similar to yesterday's. It takes half a day to one day to visit the Summer Palace. The best excursion route around 3 hours is Donggongmen, Renshou Hall, Wenchang Courtyard, Yuxi Hall, Yiyi Hall, Le Shouting, Promenade, Baiyun Hall, Foxing Pavilion, Shijie, Gengzhitu Scenic Area, Ruyi Gate. The architectural complex of the Qinzhou Mountain Front Hill is the essence of the whole park and must not be missed.
If you go to Peking University in the afternoon, you should enter from the southeast gate (requires registration of documents). You can visit the library, Unnamed Lake, Boya Tower, Cai Yuanpei and other attractions to the west. Finally, you will leave from the West Gate of Beijing University.
Summer Palace (4 hours) Subway 10 minutes Peking University (2 hours)

##### Summer Palace
Summer Palace
The most well-preserved Royal Palace, known as the "Royal Garden Museum"
![null](http://n3-q.mafengwo.net/s10/M00/3C/70/wKgBZ1n6zfyAPL4XAAmDan04ZLI50.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)


##### Beijing University
Beijing University
The sign of the beginning of modern Chinese higher education
![null](http://n4-q.mafengwo.net/s12/M00/EE/B8/wKgED1vVNE2Aat_SAFjo3VZBCyY63.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)

Traffic strategy
To the Summer Palace, you can take the subway line 4 and get off at Beigongmen Station. If you want to enter from Donggongmen, you need to get on the subway at Beigongmen Station and get off at the Summer Palace Station.
If you go to Peking University, Metro Line 4 can get off at Peking University Dongmen Station.

##### Accommodation guide
Tsinghua University-Zhongguancun is the education/science center of Beijing, with convenient transportation. Metro Line 4 and several bus lines meet here. In addition to many well-known universities, there are also attractions such as the Summer Palace and Yuanmingyuan. The second half of Beijing is recommended to stay here.



### D6 play Raiders
Today, I went to Badaling to climb the Great Wall. It should be noted that the Badaling Great Wall has two routes, south and north, and the scenery of different routes is different. A lot of time can be saved by taking the cable car. If you are still rich in physical strength and time after visiting Badaling, you can visit the Ming Tombs. It is recommended to visit Dingling first because it is the only tomb in the Ming Tombs that was opened in the Tomb of the Tomb. If there is still time to visit the Changling, where the Ming Chengzu Zhu Xi was buried.
Badaling Great Wall (3-4 hours) Bus 1 hour Ming Tombs (2 hours)

##### Badaling Great Wall
Badaling Great Wall
![null](http://b3-q.mafengwo.net/s11/M00/36/36/wKgBEFrhb3SAN3dcABAft7C2kYs76.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)
It is said that one of the world’s nine plugs is the essence of the Great Wall, and it is represented in the Ming Great Wall.

##### Ming Tombs
Ming Tombs
Feng Shui wins the world, understand the ancient imperial tomb building must go
![null](http://n3-q.mafengwo.net/s10/M00/2D/BC/wKgBZ1jbIUuAcTgPAAnYqutjakY03.jpeg?imageMogr2%2Fthumbnail%2F%21690x370r%2Fgravity%2FCenter%2Fcrop%2F%21690x370%2Fquality%2F100)

Traffic strategy
There are many ways to go to the Badaling Great Wall, which can be chosen according to your situation.
[Bus]: Take the 919 bus at Deshengmen Station and get off at Badaling Forest Park. The fare is 12 yuan. If you use the municipal traffic card, there will be a discount. If you don't have a traffic jam, you can arrive within an hour.
[Train S2 line]: The fare is 6 yuan, you need to take a bus at Beijing North Railway Station, and you can reach the scenic spot in 1.5 hours. Although it takes a relatively long time, the environment is comfortable, and the Great Wall scene such as Juyongguan and Shuiguan can be seen on the train.


From Badaling to the Ming Tombs scenic spot, you can take the corresponding bus to Dagongmen Station at Badaling Great Wall Bus Station, which can be reached in about 1.5 hours. It takes about 40 kilometers to drive by car, and it takes about 1 hour. It is more convenient to return to the Beijing area from the Ming Tombs/Changping. Take the subway, Changping Line.

##### traffic
Dining guide
The Badaling Great Wall is a suburban attraction. It is not convenient to dine around. It is recommended to bring some food dry food emergencies. If you have convenient transportation, you can go to Changping City for lunch.

##### Accommodation guide
Tiananmen Square - Forbidden City - Qianmen - Wangfujing is the central area of ​​Beijing, with a large number of hotels of various grades. Many of Beijing's popular attractions are also located in the above areas and can be easily reached. Also, Metro Lines 1 and 2 pass through the area, making it easy for tourists to travel.
