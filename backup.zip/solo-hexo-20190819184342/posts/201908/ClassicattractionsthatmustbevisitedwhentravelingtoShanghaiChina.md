title: Classic attractions that must be visited when traveling to Shanghai, China
date: '2019-08-09 18:07:15'
updated: '2019-08-19 10:47:55'
tags: [shanghaitour]
permalink: /articles/2019/08/09/1565345235470.html
---
## Shanghai Bund - Lujiazui

![null](https://n2-q.mafengwo.net/s10/M00/90/55/wKgBZ1mAQZ2AdtWgAAgVAyySYHo22.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The Bund is located on the Huangpu River in Huangpu District, Shanghai, which is outside Huangpu Beach. In 1844 (four years after the Qing dynasty), this area was designated as the British Concession, which is a true portrayal of the Shanghai Shili Ocean and is also the old Shanghai concession and the entire Shanghai. The starting point of the beginning of modern cities.
The Bund is across the Huangpu River, opposite the Shanghai CBD, Lujiazui.

![null](https://b1-q.mafengwo.net/s10/M00/89/8B/wKgBZ1l5-F6AWNg_AAjSj0MvFsY85.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

**1 recommendation index: **★★★
**2 route: ** Metro Line 2 People’s Square Station, walk 500 meters, connect Nanjing Road Pedestrian Street here, no cars allowed.
**3**Open all day, tickets are free, it is recommended to come back on Friday, Saturday, Sunday and evening, the Bund lights will be fully open, the night view is beautiful!
**4** can go to the Huangpu River cruise ship, the specific price is unknown, the Raiders said it is very cheap, just a few dollars, but I heard the staff in the pedestrian street ticketing agent shouted 120 yuan/person with a speaker...
**5** The people on the Bund in the tourist season are super! The traffic police are very strict, and the traffic lights are used in one direction.

![null](https://b3-q.mafengwo.net/s10/M00/89/8D/wKgBZ1l5-GGAKW_4AAomueEHtjQ43.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The Bund stands with 52 classically revival buildings of different styles. It is known as the Bund International Architecture Expo Group. It is an important historical and representative building in China's modern times and one of Shanghai's important landmarks. In November 1996, the State Council listed it as the fourth batch of national key cultural relics protection units.

![null](https://p4-q.mafengwo.net/s10/M00/9B/D2/wKgBZ1mATEqALAmTAAlv7Oqk7Ck49.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://n1-q.mafengwo.net/s10/M00/9B/D0/wKgBZ1mATEiAXc1xAAsLSb1s9wo27.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Peace Hotel is the first modernist building in the history of Shanghai's modern architecture. It is a Chicago school Gothic building. The hotel has the most distinctive nine-country special suites and many unique restaurants, banquet halls, multi-purpose halls and bars, rooftop sightseeing gardens and more. Peace Hotel is the first hotel in China to be rated as a world-famous hotel. It was once known as the “first floor of the Far East”.

![null](https://b4-q.mafengwo.net/s10/M00/9B/C8/wKgBZ1mATEGAUL8TAAvWFJlNPxs56.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Chen Yi Square. Suddenly remembered, the trampling accident... silently for the dead.

![null](https://p3-q.mafengwo.net/s10/M00/9B/D4/wKgBZ1mATE2AXexpAAlw7_j8riU73.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

[

![null](https://n4-q.mafengwo.net/s6/M00/B2/18/wKgB4lJ1MdWABIHAAAysp_8i80o98.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Bund

· Located on the Huangpu River in the Huangpu District of Shanghai, it is one of the most symbolic sights of the Shanghai city. · 1.5 km long, from south to north, on the left-hand side, is the wide Zhongshan East Road, the roadside lined up with dozens of foreign buildings of different styles. · Close to Shanghai's mother river, the Huangpu River, the Jiangshang Giants shuttle, and across the river stands the Jinmao Tower, the World Financial Center, and other skyscrapers. · At night, the rainbows on both sides of the Pujiang River are suitable for walking with the lover on the Bund, feeling the charm and romance of the “Never Night City”.



](http://m.mafengwo.cn/nb/public/sharejump.php?type=3&id=5504076&poi_type_id=3)

## 陆家嘴

Take the subway and then come to Lujiazui Station.

![null](https://n2-q.mafengwo.net/s10/M00/94/6D/wKgBZ1mARTWAFJ6PAAkvMvrB42M30.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Once out of the subway, Shanghai's landmark building, the ** Oriental Pearl Tower, is insight.

![null](https://p2-q.mafengwo.net/s10/M00/94/86/wKgBZ1mARUKAXHA3AAe1OFEppQg38.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

I recommend not to buy tickets for [Oriental Pearl] and [Shanghai World Financial Tower]. More than 100 yuan is to take a picture of the heights of Shanghai. During the peak period, it will line up for 1-2 hours. Go up and watch for a few minutes. It’s down.
When I came to Shanghai seven years ago, I went to the [Oriental Pearl] and watched it. At that time, I followed the tour group and waited in the elevator for a long time. After going up, there was nothing to watch. Many telescope equipment were broken. When I was doing the Raiders, I saw a lot of people complaining about the "unpredictable" of the "Pearl of the Orient", so I remind everyone to choose carefully.

![null](https://b4-q.mafengwo.net/s10/M00/94/74/wKgBZ1mARTmAfw5BAAj1c6xQo9I35.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Take a walk around and take a photo.

[

![null](https://n4-q.mafengwo.net/s10/M00/EE/C1/wKgBZ1t_OmCALJvzABEFpxlSeac99.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## 陆家嘴

Lujiazui is located on the banks of the Huangpu River in the Pudong New Area. It is opposite to the Bund, and the leading financial and business district at home and abroad is now the most attractive place in Shanghai. · Bringing together the high-rise buildings such as the Oriental Pearl Tower, the Shanghai International Convention Center, and the World Financial Center. The skyscrapers are like people in a city forest. · In the evening, standing on the high-rise buildings, overlooking the bright night scenes, will feel the modernity of the first-tier cities. · This is a place where fashionistas gather, a variety of international big names, good places to shop.



](https://m.mafengwo.cn/nb/public/sharejump.php?type=3&id=5119&poi_type_id=3)

## Shanghai Nanjing Road Pedestrian Street

![null](https://b3-q.mafengwo.net/s10/M00/89/95/wKgBZ1l5-GeASryUAAne7-qCigQ44.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Nanjing Road Pedestrian Street starts from Tibet Middle Road in the west and runs to Henan Middle Road in the east. There are dark red marble screens on both ends of the pedestrian street. The above are the six characters of “Nanjing Road Pedestrian Street” written by President Jiang Zemin. This pedestrian street, which was completed on the 50th anniversary of the National Day, has transformed the “100-year-old Nanjing Road” into another beautiful new city landscape in Shanghai.

![null](https://b2-q.mafengwo.net/s10/M00/B1/45/wKgBZ1mAbAyAYl_yAAsLT0c8lWk09.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

**1 recommendation index: **★★★
**2 route: ** Metro Line 2 People's Square Station, can't ride a bicycle, walk.
**3 opening hours: **10:00-22:00
**4 tickets are free. **

![null](https://b4-q.mafengwo.net/s10/M00/B6/F1/wKgBZ1mAc0qAUDk3AAxgN5jJVWw92.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Shanghai's first department store.

![null](https://b1-q.mafengwo.net/s10/M00/B6/F4/wKgBZ1mAc06ASEMZAAo7b1ZNNqw92.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

At the intersection of the New World Shopping Mall in Nanjing Pedestrian Street, there are many beautiful sightseeing buses. It is recommended that you take a sightseeing bus to enjoy the night view of Shanghai at night. It is also great!

![null](https://b4-q.mafengwo.net/s10/M00/B6/F6/wKgBZ1mAc1GAN84fAAq0aC5WEYM76.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The pedestrian street is very lively at night or during the day. There are many shops and snacks, and the lights are particularly bustling at night.

![null](https://n3-q.mafengwo.net/s10/M00/89/9A/wKgBZ1l5-GuAflFMAA4wXfbPgCc67.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Once the Paramount, now the department store.

![null](https://n2-q.mafengwo.net/s10/M00/B1/53/wKgBZ1mAbByAXE9ZAA9DnzVdMK861.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://b2-q.mafengwo.net/s10/M00/B1/5A/wKgBZ1mAbCOARc-rAAyq-VIVf3g55.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The pedestrian street still maintains the signature style of the 1930s.

![null](https://n3-q.mafengwo.net/s10/M00/B1/5F/wKgBZ1mAbCmAKOZFAAwec9-ykwc36.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The New World has two malls, one at the head and one at the end. This is called the Daimaru Department Store.

![null](https://b4-q.mafengwo.net/s10/M00/B1/5C/wKgBZ1mAbCaAesEKAAn4xrPPtXA47.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Eat here, only 90 yuan for dinner, a good deal!

![null](https://p4-q.mafengwo.net/s10/M00/B8/35/wKgBZ1mAdQuAZVGDAAtQIFI6FII64.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

**Tips:**
New World Mall closed at 22:00 on time, very capricious!

The food on the basement level of the old New World Department Store.

![null](https://n1-q.mafengwo.net/s10/M00/B8/2D/wKgBZ1mAdQGAaTpDAAoI-X05L1s29.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

This pot helmet is super delicious! To line up! Recommended beef and plum flavor, beef 10 yuan, Mei Cai 9 yuan! Be sure to eat!

![null](https://b1-q.mafengwo.net/s10/M00/B8/2F/wKgBZ1mAdQWAVmBiAAxoyuX38H871.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)




![null](https://n2-q.mafengwo.net/s11/M00/71/F2/wKgBEFtkT3WAWNHLAASGIzip98E36.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Nanjing Road Pedestrian Street

· One of the top ten famous pedestrian streets in China is the first commercial street established after the opening of Shanghai. · This is a gathering place for department stores, with a complete range of goods and a paradise for shoppers. · Creative urban sculptures can be seen everywhere. There are also a large number of chairs in the center of the street for tourists to sit down, and the art is full of fashion. · Nanjing Road Pedestrian Street, you can see the shuttle bus like the miniature version of the old tram, very old Shanghai taste, may wish to experience it.




##城隍庙 Yuyuan

![null](https://b4-q.mafengwo.net/s10/M00/BC/CF/wKgBZ1mAevqAR_zyAA5PEH2OMmY75.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Shanghai Chenghuang Temple is located in the most prosperous Yuyuan Scenic Spot in Shanghai.
  
**1 recommendation index: **★
**2 route: ** Subway Line 10 Yuyuan Station, 875 meters walk. (Recommended to share a bicycle)
**3 tickets: ** 40 yuan in the peak season, 30 yuan in the offseason.
**4 opening hours: **8:30~16:30
  
It’s not fun here, it’s just a famous tourist attraction in Shanghai.

![null](https://n3-q.mafengwo.net/s10/M00/BC/D3/wKgBZ1mAewCAJ0M4ABAwau4ZBPI19.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://p2-q.mafengwo.net/s10/M00/BC/DF/wKgBZ1mAexGAbEbFAAzOb8qpcDg85.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Shanghai Chenghuang Temple is one of the “Three Greatest Temples of the Yangtze River”. The city, also known as the city god, the city grandfather. It is one of the most important gods in Chinese religious culture. It is played by the heroes of the local people who are conducive to the local people. It is the god of Chinese folk and Taoism who believes in the city.

![null](https://p4-q.mafengwo.net/s10/M00/BC/E7/wKgBZ1mAexqAMbtFAAxjqDcky6c76.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The legend of the Shanghai Chenghuang Temple was built by the Emperor Wu of the Three Kingdoms. During the Ming Dynasty, it was converted into the Chenghuang Temple. 

![null](https://p3-q.mafengwo.net/s10/M00/BC/EC/wKgBZ1mAeyCAHztIAAiLCLhGxDA96.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The Yu Garden is a classical garden in the south of the Yangtze River. There are many stone statues in it. It has been going forward for seven years, and I feel that there is nothing to look good.

![null](https://p2-q.mafengwo.net/s10/M00/BC/F2/wKgBZ1mAeyyAEdiaAAeMXyWtSew52.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

I was closed when I came.

![null](https://n1-q.mafengwo.net/s10/M00/BC/FB/wKgBZ1mAezeAaaoxAA1zj6mKTmE71.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

[

![null](https://b1-q.mafengwo.net/s5/M00/5D/8A/wKgB3FEgfOqAQZRfAAu9V9g71GE48.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Shanghai Chenghuang Temple Tourist Area

· Chenghuang Temple Tourist Area contains a large area such as the Old City Temple, Yu Garden, and shopping and food products. It is a must-see for many people coming to Shanghai. · “Yuyuan” and “Old Town Temple” are private gardens and Taoist Taoist temples in the Ming Dynasty. Tickets are required for sightseeing. Other areas are open sights. · When the night falls, the entire pedestrian street will become more magnificent. Bees who like photography must not miss it. · For the first visit to Shanghai, Chenghuang Temple is the first window to fully experience Shanghai's history, culture, customs, and taste authentic Shanghai snacks.


## Tianzifang

![null](https://p2-q.mafengwo.net/s10/M00/10/8B/wKgBZ1l_VuSAA-JxAAyxpaIqK8M52.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The name "Tianzifang" is the nickname of the painter Huang Yongyu who gave this old alley a few years ago. According to historical records, "Tian Zifang" is an ancient Chinese painter who takes his homonym and uses his own words. The old street factories, the abandoned warehouses, and the ordinary people in Shikumenli were smeared with the color of Soho and more artistic.

**1 recommendation index: **★★
**2 route: ** Subway Line 9 Dapuqiao Station.
**3 opening hours: ** all day.
**4 tickets: ** free.

![null](https://n1-q.mafengwo.net/s10/M00/10/85/wKgBZ1l_VuGAdOB8AAgPNA2h5UA53.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Tianzifang is the taste of the folk house in Li Lane. In addition to creative shops and galleries, photography exhibitions, the most in a variety of cafes. The biggest feature of Tianzifang is that it still has many residents living here, similar to Gulangyu and Zengyi in Xiamen.

![null](https://p4-q.mafengwo.net/s10/M00/10/7D/wKgBZ1l_VtmAQ1BJAAoIsldOtNY50.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The most famous in Tianzifang is this **Scent Library**, which is quite famous on the Internet. I don't like perfume very much, so I only bought three bottles of red grapefruit body lotion. I just presented a bottle of red pomelo shower gel when I met the store activities. After I tried it, the effect was average.

![null](https://p3-q.mafengwo.net/s10/M00/68/95/wKgBZ1mAHK-AMp-XAAgDSI7eIVY82.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

There are also their flagship stores in the Sun Moonlight Mall.

![null](https://p1-q.mafengwo.net/s10/M00/7D/7B/wKgBZ1mAMTaAKojgAAsBywWcPMM39.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Black cloud ice cream.
The ice cream that was queued for two hours in Zhongshan Road, Xiamen two years ago, is now cold and clear in Shanghai...

![null](https://n1-q.mafengwo.net/s10/M00/10/76/wKgBZ1l_VtSAMlN0AAfJSd1ZvtU21.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

The price remains the same, the same 38 yuan, the same delicious sea salt flavor.

![null](https://p4-q.mafengwo.net/s10/M00/10/72/wKgBZ1l_VtCAdgYAAAZFecOLLEU82.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

**5 After feeling: **
Tianzifang has nothing to visit. I just went to find the smell library and just went out for 10 minutes. It's all small shops, the price is very expensive, there is a feeling of special pit visitors. The best place to go here is the famous Sun Moonlight Shopping Mall in Shanghai next to Tianzifang. It is very big, eat and drink! Worth visiting, the net red milk tea [Hi tea] is there!

[

![null](https://p1-q.mafengwo.net/s10/M00/AF/B1/wKgBZ1uA7l6AIjoSAAfkEFSJ3lQ91.jpeg?imageMogr2%2Fthumbnail%2F%21240x240r%2Fgravity%2FCenter%2Fcrop%2F%21240x240%2Fquality%2F90 )

## Tianzifang

· Evolved from the most distinctive Shikumen Lane in Shanghai, it is one of the very small locations in Puxi. ·The name is the nickname of the painter Huang Yongyu. The young man with personality and art has arrived in Shanghai for the first time and feels the unique personality of Tianzifang. · Walking in Tianzifang, walking back and forth in a labyrinth of alleys, special shops, and art workshops inadvertently jumped into sight. From teahouses, open-air restaurants, open-air cafes, galleries, home furnishings to handicrafts, as well as many well-known creative studios in Shanghai.


## 新天地

![null](https://n1-q.mafengwo.net/s10/M00/68/78/wKgBZ1mAHJWAAohDAAnO1DCoRDM65.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Shanghai Xintiandi is an urban tourist attraction with Shanghai's historical and cultural features and integration between China and the West. Based on the old Shikumen architectural area marked by modern Shanghai architecture, it changed the original residence function of Shikumen for the first time and innovated its commercial operation. Function, transforming this old house reflecting Shanghai's history and culture into a fashion, leisure culture and entertainment center with functions such as catering, shopping and performing arts.

**1 recommendation index: **★★★
**2 route: ** Subway Line 10 Xintiandi Station
**3 opening hours: ** all day, but the evening is more lively.
**4 tickets: ** free.

![null](https://n4-q.mafengwo.net/s10/M00/68/7B/wKgBZ1mAHJeAZpQhAAoJdUEtCcM18.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Hong Kong has a [Lai Kwai Fong] bar street, Shenzhen has [Sea World] Bar Bay, Shanghai has [New World] bar world, foreigners, always find their happy world in every bustling capital.

![null](https://n2-q.mafengwo.net/s10/M00/68/7D/wKgBZ1mAHJqAB5NdAAjExat1xHs44.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

![null](https://p1-q.mafengwo.net/s10/M00/68/8C/wKgBZ1mAHKaAQ3cJAA2Z_BRfeZ801.jpeg?imageView2%2F2%2Fw%2F1360%2Fq%2F90)

Xintiandi Fashion Shopping Center is also a big shopping mall, which is worth a visit.


[source](https://www.mafengwo.cn/gonglve/ziyouxing/39595.html)
