title: 我在 GitHub 上的开源项目
date: '2019-08-08 19:50:51'
updated: '2019-08-08 19:50:51'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [dev-tester](https://github.com/GitDzreal93/dev-tester) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/dev-tester/watchers "关注数")&nbsp;&nbsp;[⭐️`11`](https://github.com/GitDzreal93/dev-tester/stargazers "收藏数")&nbsp;&nbsp;[🖖`6`](https://github.com/GitDzreal93/dev-tester/network/members "分叉数")</span>

测试开发面试资源、复习资料汇总



---

### 2. [html_to_pdf](https://github.com/GitDzreal93/html_to_pdf) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/html_to_pdf/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/GitDzreal93/html_to_pdf/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/html_to_pdf/network/members "分叉数")</span>

HTML转化成PDF的小脚本



---

### 3. [solo-blog](https://github.com/GitDzreal93/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/GitDzreal93/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://qa.tencentgg.cn`](http://qa.tencentgg.cn "项目主页")</span>

Dzreal 测试开发博客 - 记录一些测试开发职场经验、工作技能、面试经验和职场感悟



---

### 4. [Web-Arsenal](https://github.com/GitDzreal93/Web-Arsenal) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/Web-Arsenal/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/Web-Arsenal/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/Web-Arsenal/network/members "分叉数")</span>

专门收集一些使用的网站



---

### 5. [hxproj](https://github.com/GitDzreal93/hxproj) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/hxproj/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/hxproj/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/hxproj/network/members "分叉数")</span>

海信 进销存系统



---

### 6. [my-new-blog](https://github.com/GitDzreal93/my-new-blog) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/my-new-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/my-new-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/my-new-blog/network/members "分叉数")</span>

我的智库



---

### 7. [batch-install-apk](https://github.com/GitDzreal93/batch-install-apk) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/batch-install-apk/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/batch-install-apk/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/batch-install-apk/network/members "分叉数")</span>

给多个手机自动安装apk



---

### 8. [GitDzreal93.github.io](https://github.com/GitDzreal93/GitDzreal93.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/GitDzreal93.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/GitDzreal93.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/GitDzreal93.github.io/network/members "分叉数")</span>





---

### 9. [static](https://github.com/GitDzreal93/static) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/static/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/static/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/static/network/members "分叉数")</span>

something



---

### 10. [wifi_parse](https://github.com/GitDzreal93/wifi_parse) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/GitDzreal93/wifi_parse/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/GitDzreal93/wifi_parse/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/GitDzreal93/wifi_parse/network/members "分叉数")</span>



