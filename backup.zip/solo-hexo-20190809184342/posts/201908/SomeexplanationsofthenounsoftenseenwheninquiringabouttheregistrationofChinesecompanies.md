title: Some explanations of the nouns often seen when inquiring about the registration
  of Chinese companies
date: '2019-08-08 15:07:40'
updated: '2019-08-09 12:59:04'
tags: [Chinesecompanies]
permalink: /articles/2019/08/08/1565248060872.html
---
This article lists some explanations of the nouns that are often seen when querying Chinese company registrations.

If you want to know what the terminology in the Chinese corporate credit information disclosure system means, we hope this article will be useful to you.
### Registered capital注册资本

Registered capital: Registered capital, also known as frontal capital, refers to the total amount of capital registered at the time of establishment. The term registered capital is rare in national company law. China is a rare country with a strict definition of registered capital. In other countries, the company law also stipulates that capital is an important matter for registration, but does not explicitly use the term registered capital. In essence, such registered capital is registered capital. However, whether the registered capital should be paid-in capital, whether it can authorize capital or issue capital registration, the legislative provisions of different countries are different.


### change log变更记录
Change record: The company's change refers to the company's establishment registration including name, residence, legal representative, registered capital, type of business (organizational form), business scope, business period, shareholders of limited liability company or the name of the promoter of the company limited by shares. Or a change in name.

### Unified social credit code统一社会信用代码

Unified social credit code: The social credit code refers to the “Notice on the General Plan for the Construction of a Unified Social Credit Code System for Legal Persons and Other Organizations for the Approval of Development and Reform Commissions and Other Organizations” (Guo Fa [2015] No. 33) The only legally-changing legal identification code issued by the competent authority to each legal entity and other organizations throughout the country. The unified social credit code consists of 18 Arabic numerals or uppercase English letters (not using I, O, Z, S, V).


### Business status经营状态

Operating status: The operating status includes business, business (closed), preparation, closure, bankruptcy and other types.




### Registered address注册地址

Registered address: The registered address of the company is the “address” registered on the company's business license. Under normal circumstances, the company has the location of its main office as the residence. Different cities have different requirements for the registered address. The requirements shall prevail.


### Business Scope经营范围

Business Scope: The business scope is the business scope of the company engaged in business activities, and should be registered by the enterprise registration authority according to law.
Applicants should refer to the "National Economic Industry Classification" to select one or more small, medium or large categories to independently apply for business scope registration. For emerging industries or specific business projects that are not regulated in the National Economic Industry Classification, they can apply for reference to policy documents, industry habits, or professional literature.


### Organization Code组织机构代码

Organization Code: The organization code is a unique, consistent identification code that is assigned to each organization based on code-making rules.



### Registration authority登记机关

Registration authority: The industrial and commercial administration authority is the company registration authority. The company is registered by the company registration authority following the law and receives the "Business License of Enterprise Legal Person" to obtain the qualification of a corporate legal person.


### Registration Number注册号

Registration No.: Industrial and commercial registration number refers to the unified identification code assigned by the industrial and commercial administrative authority when various market entities apply for registration with the industrial and commercial administration.


### National Enterprise Credit Information Publicity System全国企业信用信息公示系统

The National Enterprise Credit Information Publicity System (National Enterprise Credit Information Publicity System) was launched in February 2014. The main contents of the publicity include registration of the market entity, approval of the license, annual report, administrative punishment, spot check results, abnormal business status, and other information.
