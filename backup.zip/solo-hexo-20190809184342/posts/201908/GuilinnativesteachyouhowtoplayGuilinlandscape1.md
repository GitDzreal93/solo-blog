title: Guilin natives, teach you how to play Guilin landscape【1】
date: '2019-08-09 18:22:15'
updated: '2019-08-09 18:29:25'
tags: [guilintour]
permalink: /articles/2019/08/09/1565346135703.html
---
For thousands of years, the landscape of Guilin has caused many scholars to splash ink and attract many people to intoxicate. Take a trip to Longji Terraced Fields, go boating on the Li River, ride the Moon Hill, and go to West Street for a night out – a must-see for everyone who travels to Guilin for the first time.

![null](https://n2-q.mafengwo.net/s11/M00/B5/03/wKgBEFt9FZqAfUI-AAajYX8-tD412.jpeg?imageView2/2/w/1360/q/90) Picture: Guilin. By love

If you want to know more about Guilin than the average tourist, in addition to punching the elephant nose mountain, visiting the two rivers and four lakes, taking pictures of the Longji terraced fields, playing the Yulong River rafting, the indigenous line led by the old indigenous people of Guilin can help you understand this more. Some mountains and waters are attractive to Guilin.

![null](https://p2-q.mafengwo.net/s11/M00/04/1A/wKgBEFsDsa6AViT5AARsSCm5U2c56.jpeg?imageView2/2/w/1360/q/90) Picture: Lijiang River scenery. By 闲云居官方

## The best way to get to know a city

Lily, a native of Guilin, has lived in Guilin for 30 years. Every weekend, I will wander around the streets, go deep into the hidden corners of the city, and go up the mountain to find out what only local people know. Great food. This time, let the old native Lily of Guilin take you to know Guilin and play Guilin.

![null](https://p1-q.mafengwo.net/s1/M00/53/20/wKgIC1t7i0OAeUqGAA6dTVcBtMc68.jpeg?imageView2/2/w/1360/q/90) Picture: Lily. By love

## Best time to travel

**5-10**** months per year is the best time to visit Guilin **, because this period of rainfall is small, the climate is pleasant, the river water is moderate, suitable for boating Lijiang. However, the “May 1st” and “Eleventh” Golden Weeks are the peak period of tourism. Accommodation bookings and transportation are also tight, and prices will rise more than usual. It is recommended to avoid this time.

![null](https://p2-q.mafengwo.net/s1/M00/6F/66/wKgIC1t7wVOAHaIeAAGegmsrLAc13.jpeg?imageView2/2/w/1360/q/90) Figure: Yulonghe. By Lily_Lucy

**Tips:**
1. Guilin is in the early spring in April. It is necessary to prepare a jacket and keep warm.
2, into the rainy season in late May, the water level of the Lancang River will rise, the water flow is turbid and turbid, which is not conducive to seeing the reflection, but the temperature is not high at this time, it is cooler when it rains, and it can also be a misty dream of the river.
3, May-June, Guilin is rich in water, rainy, humid, although the daily maximum temperature is around 32 degrees, because of the humidity, the rainy season is hot, it is best to wear cool clothes.
4, July-August in the summer season, pay attention to sun protection. There are many mountains and rivers in Guilin, so it is best to wear flat shoes. Take the anti-mosquito potion.

## Guilin Essence 5th Line Recommended

Recommend 5 routes to visit Guilin, if you are about to depart for Guilin or want to go to Guilin, then this strategy is worthy of your collection!
schedule:  
**Day1 Guilin City (Two Rivers and Four Lakes - East-West Lane / Shangshui Street / Zhengyang Pedestrian Street)**
On the first day of Guilin, you can go to the small Venice "two rivers and four lakes", and then go to the east and west lanes of the influx of people to eat and gather.
**Day2 Guilin-Xingping (Xianggong Mountain - Jiu Ma Painting Mountain - Xingping Ancient Town - Lijiang Fishing Fire - Wulong Spring)**
The Bronze Awards of the International Photography Exhibition was filmed in Gongshan, the nine-horse paintings that Premier Zhou had played in, and the National Geographic magazine’s Xingping Ancient Town, which was photographed with a 20-yuan background image, and countless photographers loved the landscape. Longquan.
**Day3 Yangshuo (Yulong River Drifting - Shili Gallery - Yinziyan)**
On the third day, you can go to the Yulong River drifting that Yangshuo must play. You must experience the ride of Shili Gallery, and finally go to see the karst landform representing the cave, Yinziyan.
**Day4 Yangshuo-Guilin (Hot Balloon - Elephant Trunk Hill)**
To experience the highest-end game in Guilin - take a hot air balloon to enjoy the scenery of Guilin, and then play the Spring Mountain Evening Guilin City emblem elephant nose mountain.
**Day5 Guilin-Longsheng (Cableway Cableway - Jinfoding - Hongyao Family - Waterfall)**
Take a tour of the world's photography and shoot the Longji terraces. Take the cable car to the Golden Buddha's top, go to the local Hongyao people's home to taste the specialties, and finally return to see the quiet and quiet waterfall.

![null](https://b2-q.mafengwo.net/s11/M00/67/42/wKgBEFt-g5yAQph3AAt9SvmFQ-I07.jpeg?imageView2/2/w/1360/q/90) Picture: Minjiang fishing fire. By love

**Tips:**
Guilin's tourism essence is mainly in the surrounding areas, such as Yangshuo, Longji terraces, etc. It is best to arrange these places for 2-4 days to fully appreciate the beauty of the landscape. If you have enough time, you can visit the city of Guilin for 1 day. If the time is tight, you can skip it directly~

### D1 Guilin City (Two Rivers and Four Lakes - East-West Lane / Shangshui Street / Zhengyang Pedestrian Street)

The two rivers and four lakes in Guilin city are the city cards of Guilin, and they are also known as “Little Venice”. If you come to Guilin for the first time, you must visit the two rivers and four lakes. However, if you want to understand Guilin's eating culture, then you must go to the ** East Lane and Shangshui Food Street ** turned around. (PS to Guilin's first night is recommended to live in downtown Guilin!)

![null](https://p1-q.mafengwo.net/s2/M00/5A/D7/wKgIDFt-fNCACs99AAc5UYZtM7g457.png?imageView2/2/w/1360/q/90) Picture: First day tour route . By 爱游(Click to view larger image☝)

**Two rivers and four lakes - the water system around Venice
The two rivers and four lakes have a beautiful water system around Venice, and you can enjoy the essence of Guilin city by boat. There are two ways to visit the two rivers and four lakes. If you arrive in Guilin earlier, you can choose a day trip. If you arrive in Guilin, you will choose a night tour. **But as a native of Guilin, it is recommended to travel at night! **

![null](https://b2-q.mafengwo.net/s11/M00/41/FE/wKgBEFtz1ciAPgmHAAXQ6_zpv6w77.jpeg?imageView2/2/w/1360/q/90) Picture: Two rivers and four lakes at night. By official website

**Tips:**
Here are two-night games for the two rivers and four lakes:
1. Boat trip night tour - enjoy all the attractions
There are 3 docks for two nights in the two rivers and four lakes, such as the Sun Moon Terminal, Wenchang Pier and Jiefang Bridge Pier. After dinner in East and West Lane, it is recommended to directly choose Jiefangqiao Wharf (top)- Wenchangqiao Wharf (below). This one-way tour is more convenient for boarding, and the second tour includes all the attractions of the two rivers and four lakes.
2, lake walk - Guilin locals most local gameplay
Walking around the two rivers and four lakes are the most comfortable and local way for locals in Guilin. After dinner in East and West Lane, cross the Zhengyang Pedestrian Street to Shanhu to see the sun and moon twin towers, and then follow the road to Wuhu-Guihu-Mulong Lake. This road can feel the local flavor of Guilin, the most important thing is Also free!

Regarding the purchase of the two rivers and four lakes, you want to buy a ticket at the dock ticket office on board the ship, or you can buy tickets on the regular website. However, there will be a lot of oxen in the vicinity of the general ticket office saying that they are selling at a low price. You should not be fooled. ** Some tickets are hard to buy, and sometimes they are not necessarily available on the spot, especially during the holidays. So, quietly give you directions, poke the "consultation" / "contact the local butler"!
  
** East-West Lane - New Network Red "Paradise for Eating" **
The East-West Lane is the only historical street left by the Ming and Qing Dynasties in Guilin. It was officially opened in 2016**. It has become a gathering place for local young people and foreign tourists in Guilin. In addition to Guilin rice noodles, there are also Haidilao, authentic Hunan dishes, steel pipe factory string, etc., but if you want to pursue cost-effectively, you can also go to nearby Zhengyang Street or Shangshui Food Street! But the taste and sanitation are not as good as the things!

![null](https://b3-q.mafengwo.net/s11/M00/76/17/wKgBEFt8tT-AXHW8AAXba9Sk_zw01.jpeg?imageView2/2/w/1360/q/90) Picture: East and West Lane. By Lingyu

### D2 Guilin-Xingping (Xianggong Mountain - Jiu Ma Painting Mountain - Xingping Ancient Town - Wulong Spring)

At the top of the 10th International Photography Exhibition, the bronze medal was awarded to the Gonggong Mountain, and God's view was taken from the perspective of God. The old indigenous people went deep into the presidential town of Xingping; together with Premier Zhou, they counted the nine horses and contacted the Lijiang River; A photo of the Yuan Renminbi background, watch the fire to the BBC's Lijiang fishermen. This day's itinerary is the essence of Guilin.

** Xianggongshan - **** 10th International Film Festival Bronze Shooting Location**
The photographic land of the 10th International Film Festival Bronze Award ** Xianggong Mountain is located in Xingping, Yangshuo. It is a photography treasure that only photographers and old people in Guilin can find. The misty rains of the Lancang River and the sunrise of the Yunhai... countless moving images are from here. When you look up, you can see the panoramic view of the Lijiang Bay. It takes 20 minutes to get to the top of the mountain from the foot of the mountain.

![null](https://n2-q.mafengwo.net/s11/M00/89/98/wKgBEFt2JmaAHJfSAAo4FaImh9M191.png?imageView2/2/w/1360/q/90) Picture: Xianggong Mountain. By love

**Jiu Ma Painting Mountain - Counting nine horses together with Premier Zhou
It is said that Premier Zhou Enlai saw nine horses when he visited the mountains and nine horses, while former US President Bill Clinton saw eight horses. The Jiu Ma Painting Mountain is connected by nine mountain peaks and is adjacent to the bank of the Li River. It is one of the famous landscapes of the Lijiang River in Guilin. However, the cruise ship and the bamboo raft are short-lived. Many times have not been reflected, but the best way to watch it is the riverbank of the Nine Horses. But most people don’t know the place to watch. If you want to go, you can Poke "** Contact local butler**" consultation!

![null](https://n2-q.mafengwo.net/s11/M00/1A/5A/wKgBEFtyMymAeFLjABOUwhAysLU53.jpeg?imageView2/2/w/1360/q/90) Picture: Counting nine-horse painting mountains. By love



![null](https://b3-q.mafengwo.net/s11/M00/35/9B/wKgBEFseLvOACD5PAAv257-ubeU56.jpeg?imageMogr2/thumbnail/!240x240r/gravity/Center/crop/!240x240/quality/90 )

[source](https://www.mafengwo.cn/gonglve/ziyouxing/332.html)
